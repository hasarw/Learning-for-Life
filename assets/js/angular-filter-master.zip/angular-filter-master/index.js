require('./dist/angular-filter.js');
module.exports = 'angular.filter';
